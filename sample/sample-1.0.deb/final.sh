#!/bin/bash
echo " current time is: "$(date +"%T") 2>&1 

